<?php
$DataBase = array(
	"hostname" => "localhost",
	"username" => "mysql_user",
	"password" => "MysqlPass",
	"name" => "mysql_db"
);
?>