<div class="container-fluid">
	<div class="card text-center">
		<h1 class="mb-0"><?php echo $text['503_title'];?></h1>
		<h5 class="mb-0"><?php echo $text['503_subtitle'];?></h5>
		<p><?php echo $text['503_text'];?></p>
	</div>
</div>