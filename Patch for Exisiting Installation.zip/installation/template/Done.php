<div class="container-fluid" id='login'>	
	<div class="row">
		<div class="col-md-6 offset-md-3 col-lg-4 offset-lg-4">
			<div class="card mx-30" style="opacity: 80%">
				<div class="text-center">
					<i class="fa fa-info-circle fa-5x icon-text"></i>
					<h3 class="my-0">Congratulations</h3>
					<p class="my-0 mb-5">You have successfully updated MOFHY. Please click on the button bellow to log into your admin panel. <i class="fa fa-smile"></i><br>
					Don't forget to rename or delete the installation folder.
					</p>
					<a href="../admin/" class="btn btn-primary">Login Now!</a>
				</div>
			</div>
		</div>
	</div>
</div>