<?php
	header('location: ../');
?>